package com.adiaz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestendpointgetApplication{

	public static void main(String[] args) {
		SpringApplication.run(RestendpointgetApplication.class, args);
	}

}
